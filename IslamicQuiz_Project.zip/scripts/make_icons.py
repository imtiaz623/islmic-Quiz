#!/usr/bin/env python3
"""Generates the app icon (green + gold Islamic theme) and Android resource PNGs.
Run:  python3 scripts/make_icons.py   (needs Pillow)
Output: assets/icon-1024.png and assets/android-res/*  (copied into the Android project by patch-android.mjs)
"""
import math, os
from PIL import Image, ImageDraw, ImageFilter

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
OUT = os.path.join(ROOT, "assets", "android-res")
GREEN_D, GREEN, GREEN_L = (6, 64, 43), (11, 93, 59), (20, 128, 79)
GOLD, GOLD_L, GOLD_D = (212, 175, 55), (243, 215, 122), (168, 138, 31)
S = 1024

def radial_bg(size):
    img = Image.new("RGB", (size, size), GREEN_D)
    px = img.load()
    cx, cy = size * 0.5, size * 0.32
    maxd = size * 0.95
    for y in range(size):
        for x in range(size):
            d = min(1.0, math.hypot(x - cx, y - cy) / maxd)
            t = d
            if t < 0.5:
                k = t / 0.5
                c = tuple(int(GREEN_L[i] + (GREEN[i] - GREEN_L[i]) * k) for i in range(3))
            else:
                k = (t - 0.5) / 0.5
                c = tuple(int(GREEN[i] + (GREEN_D[i] - GREEN[i]) * k) for i in range(3))
            px[x, y] = c
    return img

def star_points(cx, cy, r_out, r_in, n=8, rot=-math.pi / 2):
    pts = []
    for i in range(n * 2):
        r = r_out if i % 2 == 0 else r_in
        a = rot + i * math.pi / n
        pts.append((cx + r * math.cos(a), cy + r * math.sin(a)))
    return pts

def symbol(size):
    """Gold symbol (crescent + star + dome) on transparent canvas, designed in the central 62% safe zone."""
    k = 4  # supersample
    W = size * k
    layer = Image.new("RGBA", (W, W), (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    u = W / 100.0  # 1 unit = 1% of canvas

    # Crescent: big gold disc minus offset disc
    cx, cy, R = 50 * u, 40 * u, 21 * u
    d.ellipse([cx - R, cy - R, cx + R, cy + R], fill=GOLD_L + (255,))
    cut = Image.new("L", (W, W), 0)
    ImageDraw.Draw(cut).ellipse([cx - R * 0.78 + 7 * u, cy - R * 0.78 - 1 * u, cx + R * 0.78 + 7 * u, cy + R * 0.78 - 1 * u], fill=255)
    alpha = layer.split()[3]
    alpha = Image.composite(Image.new("L", (W, W), 0), alpha, cut)
    layer.putalpha(alpha)
    d = ImageDraw.Draw(layer)

    # Star inside the crescent mouth
    d.polygon(star_points(cx + 9.5 * u, cy - 1 * u, 7.5 * u, 3.4 * u, n=8), fill=GOLD + (255,))

    # Mosque dome + minarets (bottom)
    base_y = 80 * u
    dome_cx, dome_r = 50 * u, 15 * u
    d.pieslice([dome_cx - dome_r, base_y - dome_r * 1.25, dome_cx + dome_r, base_y + dome_r * 0.75], 180, 360, fill=GOLD + (255,))
    d.rectangle([dome_cx - dome_r - 4 * u, base_y - 0.5 * u, dome_cx + dome_r + 4 * u, base_y + 5 * u], fill=GOLD + (255,))
    # finial
    d.rectangle([dome_cx - 0.7 * u, base_y - dome_r * 1.25 - 5 * u, dome_cx + 0.7 * u, base_y - dome_r * 1.25], fill=GOLD + (255,))
    for sgn in (-1, 1):
        mx = dome_cx + sgn * (dome_r + 11 * u)
        d.rectangle([mx - 2.2 * u, base_y - 20 * u, mx + 2.2 * u, base_y + 5 * u], fill=GOLD_D + (255,))
        d.polygon([(mx - 3.2 * u, base_y - 20 * u), (mx + 3.2 * u, base_y - 20 * u), (mx, base_y - 27 * u)], fill=GOLD + (255,))
    return layer.resize((size, size), Image.LANCZOS)

def with_shadow(sym):
    sh = Image.new("RGBA", sym.size, (0, 0, 0, 0))
    a = sym.split()[3].point(lambda v: int(v * 0.45))
    sh.putalpha(a)
    sh = sh.filter(ImageFilter.GaussianBlur(sym.size[0] * 0.008))
    off = Image.new("RGBA", sym.size, (0, 0, 0, 0))
    off.paste(sh, (0, int(sym.size[0] * 0.01)), sh)
    return Image.alpha_composite(off, sym)

def ring(img_size, inset=0.03, width=0.012, color=GOLD):
    layer = Image.new("RGBA", (img_size, img_size), (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    i = img_size * inset
    d.rounded_rectangle([i, i, img_size - i, img_size - i], radius=img_size * 0.2, outline=color + (255,), width=max(2, int(img_size * width)))
    return layer

def master_icon():
    bg = radial_bg(S).convert("RGBA")
    bg = Image.alpha_composite(bg, ring(S))
    sym = with_shadow(symbol(S))
    return Image.alpha_composite(bg, sym)

def round_mask(size):
    m = Image.new("L", (size * 4, size * 4), 0)
    ImageDraw.Draw(m).ellipse([0, 0, size * 4 - 1, size * 4 - 1], fill=255)
    return m.resize((size, size), Image.LANCZOS)

def rounded_mask(size, radius_frac=0.22):
    m = Image.new("L", (size * 4, size * 4), 0)
    ImageDraw.Draw(m).rounded_rectangle([0, 0, size * 4 - 1, size * 4 - 1], radius=size * 4 * radius_frac, fill=255)
    return m.resize((size, size), Image.LANCZOS)

def main():
    os.makedirs(os.path.join(ROOT, "assets"), exist_ok=True)
    master = master_icon()
    master.save(os.path.join(ROOT, "assets", "icon-1024.png"))

    # adaptive foreground (symbol only, transparent), background is a solid color resource
    fg_full = with_shadow(symbol(S))

    dens = {"mdpi": (48, 108), "hdpi": (72, 162), "xhdpi": (96, 216), "xxhdpi": (144, 324), "xxxhdpi": (192, 432)}
    for name, (legacy, fg) in dens.items():
        d = os.path.join(OUT, f"mipmap-{name}")
        os.makedirs(d, exist_ok=True)
        sq = master.resize((legacy, legacy), Image.LANCZOS)
        sq.putalpha(rounded_mask(legacy))
        sq.save(os.path.join(d, "ic_launcher.png"))
        rd = master.resize((legacy, legacy), Image.LANCZOS)
        rd.putalpha(round_mask(legacy))
        rd.save(os.path.join(d, "ic_launcher_round.png"))
        fg_img = fg_full.resize((fg, fg), Image.LANCZOS)
        fg_img.save(os.path.join(d, "ic_launcher_foreground.png"))

    # splash: green gradient with centered icon (portrait + landscape + default)
    def splash(w, h):
        bg = radial_bg(max(w, h)).crop((0, 0, w, h)).convert("RGBA") if False else Image.new("RGBA", (w, h), GREEN + (255,))
        # gentle vertical gradient
        g = Image.new("RGBA", (w, h))
        gd = ImageDraw.Draw(g)
        for y in range(h):
            t = y / max(1, h - 1)
            c = tuple(int(GREEN_L[i] * (1 - t) * 0.6 + GREEN[i] * 0.4 + (GREEN_D[i] - GREEN[i]) * t * 0.6) for i in range(3))
            gd.line([(0, y), (w, y)], fill=c + (255,))
        side = int(min(w, h) * 0.38)
        ic = master.resize((side, side), Image.LANCZOS)
        ic.putalpha(rounded_mask(side))
        g.paste(ic, ((w - side) // 2, (h - side) // 2), ic)
        return g.convert("RGB")

    sizes = {"": (480, 800)}
    for dens_name, (pw, ph) in {"mdpi": (320, 480), "hdpi": (480, 800), "xhdpi": (720, 1280), "xxhdpi": (960, 1600), "xxxhdpi": (1280, 1920)}.items():
        for orient, (w, h) in (("port", (pw, ph)), ("land", (ph, pw))):
            d = os.path.join(OUT, f"drawable-{orient}-{dens_name}")
            os.makedirs(d, exist_ok=True)
            splash(w, h).save(os.path.join(d, "splash.png"))
    d = os.path.join(OUT, "drawable")
    os.makedirs(d, exist_ok=True)
    splash(480, 800).save(os.path.join(d, "splash.png"))
    print("icons written to", os.path.abspath(OUT))

if __name__ == "__main__":
    main()
