// Capacitor ke generate kiye hue android/ folder ko patch karta hai:
//  - AdMob App ID (www/config.js se) AndroidManifest mein
//  - portrait orientation, network permission
//  - app icon + splash (assets/android-res)
//  - versionCode / versionName (env: VERSION_CODE, VERSION_NAME)
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const androidDir = path.join(root, "android");
const res = path.join(androidDir, "app", "src", "main", "res");
const manifestPath = path.join(androidDir, "app", "src", "main", "AndroidManifest.xml");

if (!fs.existsSync(manifestPath)) {
  console.error("android/ folder nahi mila. Pehle chalayein: npx cap add android");
  process.exit(1);
}

// ---- 1. AdMob App ID config.js se parh lo ----
const cfg = fs.readFileSync(path.join(root, "www", "config.js"), "utf8");
const m = cfg.match(/APP_ID:\s*"(ca-app-pub-\d+~\d+)"/);
if (!m) { console.error("www/config.js mein ADMOB.APP_ID nahi mila"); process.exit(1); }
const appId = m[1];

// ---- 2. Manifest patch ----
let xml = fs.readFileSync(manifestPath, "utf8");

if (!xml.includes("com.google.android.gms.ads.APPLICATION_ID")) {
  xml = xml.replace(
    /(<application\b[^>]*>)/,
    `$1\n        <meta-data android:name="com.google.android.gms.ads.APPLICATION_ID" android:value="${appId}" />`
  );
}
if (!xml.includes("ACCESS_NETWORK_STATE")) {
  xml = xml.replace(/<\/manifest>/, `    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />\n</manifest>`);
}
if (!xml.includes("android:screenOrientation")) {
  xml = xml.replace(/<activity\b/, `<activity\n            android:screenOrientation="portrait"`);
}
fs.writeFileSync(manifestPath, xml);
console.log("Manifest patched, AdMob App ID:", appId);

// ---- 3. Icons + splash copy ----
const srcRes = path.join(root, "assets", "android-res");
function copyDir(src, dst) {
  for (const e of fs.readdirSync(src, { withFileTypes: true })) {
    const s = path.join(src, e.name), d = path.join(dst, e.name);
    if (e.isDirectory()) { fs.mkdirSync(d, { recursive: true }); copyDir(s, d); }
    else fs.copyFileSync(s, d);
  }
}
copyDir(srcRes, res);

// adaptive icon background colour = app green
fs.writeFileSync(
  path.join(res, "values", "ic_launcher_background.xml"),
  `<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#0B5D3B</color>\n</resources>\n`
);
console.log("Icons + splash copied");

// ---- 4. Version ----
const gradlePath = path.join(androidDir, "app", "build.gradle");
let g = fs.readFileSync(gradlePath, "utf8");
const vc = parseInt(process.env.VERSION_CODE || "1", 10) || 1;
const vn = process.env.VERSION_NAME || "1.0";
g = g.replace(/versionCode\s+\d+/, `versionCode ${vc}`).replace(/versionName\s+"[^"]*"/, `versionName "${vn}"`);
fs.writeFileSync(gradlePath, g);
console.log(`Version: ${vn} (${vc})`);
