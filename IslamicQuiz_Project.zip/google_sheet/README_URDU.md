# Islamic Quiz – Google Sheet + APK Guide

## Part 1 — Google Sheet banana (10 minute, sirf 1 baar)

1. https://sheets.new kholein (naya khali Google Sheet).
2. Menu: **Extensions → Apps Script**.
3. Wahan ka purana code hata kar `google_sheet/Code.gs` ka poora code paste karein → **Save** (💾).
4. Upar function list se **`setupSheet`** chunein → **Run** → permission **Allow** karein.
   Sheet mein 3 tabs ban jayenge (sample data ke saath): **Questions**, **Config**, **Boxes**.
   (Agar "Google hasn't verified this app" aaye: *Advanced → Go to project (unsafe)* → Allow. Ye aapka apna script hai.)
5. **Deploy → New deployment → ⚙ → Web app**
   - Execute as: **Me**
   - Who has access: **Anyone**
   → **Deploy** → jo **Web app URL** mile (`https://script.google.com/macros/s/.../exec`) use copy karein.
6. Us URL ko `www/config.js` mein `SHEET_API_URL: "..."` ke andar paste karein
   (ya GitHub mein *Settings → Secrets and variables → Actions → Variables → New variable* `SHEET_API_URL`).

> Is URL wale data mein sirf sawal/text/colors hain — koi password ya private cheez nahi. Sheet ko sirf wahi edit kar sakta hai jise aap Share karein.
> Agar `Code.gs` dobara badlein to: *Deploy → Manage deployments → ✏ Edit → Version: New version → Deploy* (URL wahi rehta hai).

Agar Apps Script nahi lagana chahte: `IslamicQuiz_Sheet_Template.xlsx` ko Google Drive mein upload karke "Open with Google Sheets" karein — lekin app ko data dene ke liye phir bhi Code.gs (Step 2–5) chahiye.

## Part 2 — Sheet se kya kya badal sakte hain

App khulte hi, wapas aate hi, aur khula ho to har ~60 second baad Sheet check karti hai. Upar-right ↻ button se foran bhi.
Naya sawal add karein to **agla sawal wahi aata hai**. APK dobara banane ki zaroorat nahi.

### Tab `Questions` (har row = 1 sawal)
| Column | Matlab |
|---|---|
| id | Koi bhi unique naam/number (khali chhor sakte hain) |
| active | ✔ = dikhe, khali = chhupa do (delete kiye bina) |
| question | Sawal |
| correct | Sahi jawab |
| wrong1, wrong2, wrong3 | 3 ghalat options (options app khud random order mein lagati hai) |
| category | Optional – sawal ke upar chhota tag |
| min_level | Optional – is level ke baad hi ye sawal aaye (default 1) |
| coins | Optional – is sawal ke sahi jawab par alag coins (khali = Config wale) |
| explanation | Optional – galat jawab ke popup mein dikhega |

### Tab `Config` (key ko mat badlein, sirf `value` badlein)
Text: `app_title`, `app_subtitle`, `welcome_title`, `welcome_text`, `start_button_text`, `correct_message`, `wrong_title`, `wrong_text`, `timeout_title`, `next_button_text`, `level_up_title`, `level_up_text`, `ad_button_text`, `announcement` (top par khaas ittela).
Game: `coins_per_correct`, `coins_per_ad`, `coins_per_level`, **`question_time_seconds`** (timer, default 15), `next_delay_ms`, `ad_daily_limit` (0 = unlimited).
Awaaz: `voice_enabled`, `voice_correct_text`, `voice_wrong_text`, `voice_lang`, `voice_rate` — awaaz **sirf sahi/galat jawab** bolti hai.
Ads: `ads_enabled`, `banner_enabled`, `test_ads` (**TRUE = Google ke test ads** – testing ke dauran TRUE rakhein, release par FALSE).
Colors: `color_green`, `color_green_dark`, `color_green_light`, `color_gold`, `color_gold_light`, `color_cream`, `color_red` (jaise `#0b5d3b`).
Nayi key apne aap app mein nahi aati; sirf in maujooda keys ki value badalti hai.

### Tab `Boxes` (home screen par naye boxes — jitne chahein)
| Column | Matlab |
|---|---|
| id | Unique naam (reward box ke liye zaroori — 24 ghante ka hisaab isi se rakha jata hai) |
| active | ✔ = dikhe |
| order | 1, 2, 3 … dikhne ki tarteeb |
| type | `info` (sirf text), `link` (button jo website kholega), `reward` (24 ghante mein 1 baar free coins), `image` (tasveer) |
| icon | Koi emoji, jaise 🎁 |
| title, body | Heading aur text |
| button_text | Button par likha text |
| url | `link` type ke liye https:// link |
| coins | `reward` type ke liye kitne coins |
| image_url | `image` type ke liye https:// tasveer ka link |
| bg_color, text_color | Optional rang, jaise `#14804f` |

## Part 3 — GitHub par APK banana

1. https://github.com par naya repository banayein (Private theek hai).
2. Is poore folder ki files upload karein (zip khol kar andar ki files: `www`, `assets`, `scripts`, `.github`, `package.json`, `package-lock.json`, `capacitor.config.json` …).
   > `.github` folder chhupa hua hota hai; web upload mein drag-drop se jata hai, ya `git push` karein.
3. Repo mein **Actions** tab → **Build Android APK** → (push par khud chalta hai) ya **Run workflow**.
4. ~5–10 minute baad build ke andar **Artifacts → IslamicQuiz-debug-apk** download karein, zip kholein, `app-debug.apk` phone mein install karein ("Unknown sources" allow karna hoga).

**Play Store / signed release ke liye (optional):** keystore banayein
`keytool -genkeypair -v -keystore release.keystore -alias quiz -keyalg RSA -keysize 2048 -validity 10000`
phir `base64 -w0 release.keystore` ki output ko repo secrets mein `KEYSTORE_BASE64` banayein, aur saath `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`. Ab har build **IslamicQuiz-release-apk** bhi dega. Keystore file ko hamesha mehfooz rakhein — kho gayi to app update nahi ho sakegi.

## Part 4 — Zaroori baatein

- **Icon / splash:** `assets/icon-1024.png` aap ka icon hai. Badalna ho to `scripts/make_icons.py` badal kar `python3 scripts/make_icons.py` chalayein (Pillow chahiye) aur nayi `assets/` files commit karein.
- **Package name:** `capacitor.config.json` mein `appId` (`com.islamicquiz.game`). Agar AdMob mein app Play Store se link ki hai to wahi package name likhein, warna jaisa hai rehne dein.
- **AdMob IDs:** `www/config.js` mein hain (App ID, Banner, Rewarded). App ID khud AndroidManifest mein lag jata hai.
- **Testing:** apne asli ads par khud click mat karein (AdMob account band ho sakta hai). Test karna ho to Sheet mein `test_ads = TRUE`. Naye ad units par pehle kuch ghanton tak ads fill nahi hote — ye normal hai.
- **Awaaz:** phone ke TTS engine mein Hindi/Urdu voice ho to behtar bolta hai; `voice_lang` ko `hi-IN`, `ur-PK` ya `en-US` kar ke dekh lein.
- **Offline:** internet na ho to pichli dafa ka Sheet data (cache) chalta hai; pehli dafa bina internet ke andar ke 42 sawal.
