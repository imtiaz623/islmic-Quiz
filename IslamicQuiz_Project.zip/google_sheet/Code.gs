/**
 * ISLAMIC QUIZ - Google Sheet backend  (Google Apps Script)
 * ---------------------------------------------------------
 * Kaise lagayein (sirf 1 baar):
 *  1. Naya Google Sheet banayein  ->  menu: Extensions > Apps Script
 *  2. Is poori file ko wahan paste karein (purana code hata kar)  ->  Save
 *  3. Upar function list se  setupSheet  chunein  ->  Run  (permission allow karein)
 *     Ye 3 tabs bana dega: Questions, Config, Boxes (sample data ke saath).
 *  4. Deploy > New deployment > type: Web app
 *        Execute as: Me      |   Who has access: Anyone
 *     Deploy dabayein, aur jo "Web app URL" mile use copy karein.
 *  5. Wo URL app ki  www/config.js  mein  SHEET_API_URL  ki jagah paste karein.
 *
 * Uske baad sheet mein koi bhi change (naya sawal, rang, text, naya box) app mein
 * khud nazar aa jata hai (app khulte hi, wapas aane par, aur har ~60 second baad).
 * Code.gs mein dobara kuch badalne par: Deploy > Manage deployments > Edit > New version.
 */

var TABS = { questions: 'Questions', config: 'Config', boxes: 'Boxes' };

var Q_HEADERS = ['id', 'active', 'question', 'correct', 'wrong1', 'wrong2', 'wrong3', 'category', 'min_level', 'coins', 'explanation'];
var CONFIG_HEADERS = ['key', 'value', 'note'];
var BOX_HEADERS = ['id', 'active', 'order', 'type', 'icon', 'title', 'body', 'button_text', 'url', 'coins', 'image_url', 'bg_color', 'text_color'];

var SEED = {
 "questions": [
  {
   "id": "q1",
   "active": true,
   "question": "Islam ke kitne arkaan (pillars) hain?",
   "correct": "5",
   "wrong1": "4",
   "wrong2": "6",
   "wrong3": "7",
   "category": "General",
   "min_level": 1,
   "coins": "",
   "explanation": ""
  },
  {
   "id": "q2",
   "active": true,
   "question": "Quran Majeed mein kitne paras (juz) hain?",
   "correct": "30",
   "wrong1": "28",
   "wrong2": "40",
   "wrong3": "114",
   "category": "General",
   "min_level": 1,
   "coins": "",
   "explanation": ""
  },
  {
   "id": "q3",
   "active": true,
   "question": "Quran Majeed mein kitni suratein hain?",
   "correct": "114",
   "wrong1": "100",
   "wrong2": "120",
   "wrong3": "99",
   "category": "General",
   "min_level": 1,
   "coins": "",
   "explanation": ""
  },
  {
   "id": "q4",
   "active": true,
   "question": "Sab se pehli wahi (revelation) kis jagah nazil hui?",
   "correct": "Ghar-e-Hira",
   "wrong1": "Ghar-e-Soor",
   "wrong2": "Masjid-e-Nabawi",
   "wrong3": "Mina",
   "category": "General",
   "min_level": 1,
   "coins": "",
   "explanation": ""
  },
  {
   "id": "q5",
   "active": true,
   "question": "Rasoolullah ﷺ ki wiladat kis shehar mein hui?",
   "correct": "Makkah Mukarramah",
   "wrong1": "Madina Munawwara",
   "wrong2": "Taif",
   "wrong3": "Quds",
   "category": "General",
   "min_level": 1,
   "coins": "",
   "explanation": ""
  },
  {
   "id": "q6",
   "active": true,
   "question": "Hijrat kis shehar ki taraf hui?",
   "correct": "Madina",
   "wrong1": "Taif",
   "wrong2": "Habsha",
   "wrong3": "Yemen",
   "category": "General",
   "min_level": 1,
   "coins": "",
   "explanation": ""
  },
  {
   "id": "q7",
   "active": true,
   "question": "Islam ke pehle khalifa kaun the?",
   "correct": "Hazrat Abu Bakr (RA)",
   "wrong1": "Hazrat Umar (RA)",
   "wrong2": "Hazrat Usman (RA)",
   "wrong3": "Hazrat Ali (RA)",
   "category": "General",
   "min_level": 1,
   "coins": "",
   "explanation": ""
  },
  {
   "id": "q8",
   "active": true,
   "question": "Quran Majeed ki sab se lambi surat kaun si hai?",
   "correct": "Surah Al-Baqarah",
   "wrong1": "Surah Al-Imran",
   "wrong2": "Surah An-Nisa",
   "wrong3": "Surah Yaseen",
   "category": "General",
   "min_level": 1,
   "coins": "",
   "explanation": ""
  },
  {
   "id": "q9",
   "active": true,
   "question": "Quran Majeed ki sab se chhoti surat kaun si hai?",
   "correct": "Surah Al-Kausar",
   "wrong1": "Surah Al-Ikhlas",
   "wrong2": "Surah Al-Asr",
   "wrong3": "Surah An-Nas",
   "category": "General",
   "min_level": 1,
   "coins": "",
   "explanation": ""
  },
  {
   "id": "q10",
   "active": true,
   "question": "Din mein kitni namazein farz hain?",
   "correct": "5",
   "wrong1": "3",
   "wrong2": "4",
   "wrong3": "6",
   "category": "General",
   "min_level": 1,
   "coins": "",
   "explanation": ""
  },
  {
   "id": "q11",
   "active": true,
   "question": "Ramadan ke roze kis hijri mahine mein rakhe jate hain?",
   "correct": "Ramadan",
   "wrong1": "Shaban",
   "wrong2": "Shawwal",
   "wrong3": "Muharram",
   "category": "General",
   "min_level": 1,
   "coins": "",
   "explanation": ""
  },
  {
   "id": "q12",
   "active": true,
   "question": "Kaaba ki taameer kis nabi ne ki (Hazrat Ismail ke sath)?",
   "correct": "Hazrat Ibrahim (AS)",
   "wrong1": "Hazrat Musa (AS)",
   "wrong2": "Hazrat Nuh (AS)",
   "wrong3": "Hazrat Isa (AS)",
   "category": "General",
   "min_level": 1,
   "coins": "",
   "explanation": ""
  },
  {
   "id": "q13",
   "active": true,
   "question": "Hazrat Yunus (AS) ko kis ne nigal liya tha?",
   "correct": "Machli ne",
   "wrong1": "Sher ne",
   "wrong2": "Saanp ne",
   "wrong3": "Samandar ki lehar ne",
   "category": "General",
   "min_level": 1,
   "coins": "",
   "explanation": ""
  },
  {
   "id": "q14",
   "active": true,
   "question": "Sab se pehle insan aur nabi kaun the?",
   "correct": "Hazrat Adam (AS)",
   "wrong1": "Hazrat Nuh (AS)",
   "wrong2": "Hazrat Idris (AS)",
   "wrong3": "Hazrat Ibrahim (AS)",
   "category": "General",
   "min_level": 1,
   "coins": "",
   "explanation": ""
  },
  {
   "id": "q15",
   "active": true,
   "question": "Kashti (Ark) kis nabi ne banai thi?",
   "correct": "Hazrat Nuh (AS)",
   "wrong1": "Hazrat Yusuf (AS)",
   "wrong2": "Hazrat Musa (AS)",
   "wrong3": "Hazrat Hud (AS)",
   "category": "General",
   "min_level": 1,
   "coins": "",
   "explanation": ""
  },
  {
   "id": "q16",
   "active": true,
   "question": "Zakat ka maqsad kya hai?",
   "correct": "Maal ko paak karna aur gareebon ki madad",
   "wrong1": "Sirf tijarat badhana",
   "wrong2": "Sirf Eid manana",
   "wrong3": "Safar ka kharcha",
   "category": "General",
   "min_level": 1,
   "coins": "",
   "explanation": ""
  },
  {
   "id": "q17",
   "active": true,
   "question": "Hajj kis hijri mahine mein ada kiya jata hai?",
   "correct": "Zil Hijjah",
   "wrong1": "Rajab",
   "wrong2": "Safar",
   "wrong3": "Rabi-ul-Awwal",
   "category": "General",
   "min_level": 1,
   "coins": "",
   "explanation": ""
  },
  {
   "id": "q18",
   "active": true,
   "question": "Islam ka pehla rukn kya hai?",
   "correct": "Kalima Shahadat",
   "wrong1": "Namaz",
   "wrong2": "Roza",
   "wrong3": "Hajj",
   "category": "General",
   "min_level": 1,
   "coins": "",
   "explanation": ""
  },
  {
   "id": "q19",
   "active": true,
   "question": "Jang-e-Badr kis hijri saal mein hui?",
   "correct": "2 Hijri",
   "wrong1": "1 Hijri",
   "wrong2": "5 Hijri",
   "wrong3": "8 Hijri",
   "category": "General",
   "min_level": 1,
   "coins": "",
   "explanation": ""
  },
  {
   "id": "q20",
   "active": true,
   "question": "Hazrat Muhammad ﷺ ki walida ka naam kya tha?",
   "correct": "Hazrat Amina",
   "wrong1": "Hazrat Khadija",
   "wrong2": "Hazrat Aisha",
   "wrong3": "Hazrat Fatima",
   "category": "General",
   "min_level": 1,
   "coins": "",
   "explanation": ""
  },
  {
   "id": "q21",
   "active": true,
   "question": "Rasoolullah ﷺ ki pehli biwi kaun thin?",
   "correct": "Hazrat Khadija (RA)",
   "wrong1": "Hazrat Aisha (RA)",
   "wrong2": "Hazrat Hafsa (RA)",
   "wrong3": "Hazrat Zainab (RA)",
   "category": "General",
   "min_level": 1,
   "coins": "",
   "explanation": ""
  },
  {
   "id": "q22",
   "active": true,
   "question": "Aakhri nabi kaun hain?",
   "correct": "Hazrat Muhammad ﷺ",
   "wrong1": "Hazrat Isa (AS)",
   "wrong2": "Hazrat Musa (AS)",
   "wrong3": "Hazrat Ibrahim (AS)",
   "category": "General",
   "min_level": 1,
   "coins": "",
   "explanation": ""
  },
  {
   "id": "q23",
   "active": true,
   "question": "Hazrat Musa (AS) par kaun si kitab nazil hui?",
   "correct": "Torat",
   "wrong1": "Zaboor",
   "wrong2": "Injeel",
   "wrong3": "Sahifa",
   "category": "General",
   "min_level": 1,
   "coins": "",
   "explanation": ""
  },
  {
   "id": "q24",
   "active": true,
   "question": "Hazrat Dawood (AS) par kaun si kitab nazil hui?",
   "correct": "Zaboor",
   "wrong1": "Torat",
   "wrong2": "Injeel",
   "wrong3": "Quran",
   "category": "General",
   "min_level": 1,
   "coins": "",
   "explanation": ""
  },
  {
   "id": "q25",
   "active": true,
   "question": "Hazrat Isa (AS) par kaun si kitab nazil hui?",
   "correct": "Injeel",
   "wrong1": "Zaboor",
   "wrong2": "Torat",
   "wrong3": "Quran",
   "category": "General",
   "min_level": 1,
   "coins": "",
   "explanation": ""
  },
  {
   "id": "q26",
   "active": true,
   "question": "Wahi lane wale farishte ka naam kya hai?",
   "correct": "Hazrat Jibraeel (AS)",
   "wrong1": "Hazrat Mikaeel (AS)",
   "wrong2": "Hazrat Israfeel (AS)",
   "wrong3": "Hazrat Azraeel (AS)",
   "category": "General",
   "min_level": 1,
   "coins": "",
   "explanation": ""
  },
  {
   "id": "q27",
   "active": true,
   "question": "Soor (Sur) phoonkne par kaun sa farishta mamoor hai?",
   "correct": "Hazrat Israfeel (AS)",
   "wrong1": "Hazrat Jibraeel (AS)",
   "wrong2": "Hazrat Mikaeel (AS)",
   "wrong3": "Hazrat Azraeel (AS)",
   "category": "General",
   "min_level": 1,
   "coins": "",
   "explanation": ""
  },
  {
   "id": "q28",
   "active": true,
   "question": "Jumma ki namaz kis din ada ki jati hai?",
   "correct": "Juma (Friday)",
   "wrong1": "Sunday",
   "wrong2": "Monday",
   "wrong3": "Saturday",
   "category": "General",
   "min_level": 1,
   "coins": "",
   "explanation": ""
  },
  {
   "id": "q29",
   "active": true,
   "question": "Eid-ul-Fitr kis mahine ki pehli tareekh ko hoti hai?",
   "correct": "Shawwal",
   "wrong1": "Ramadan",
   "wrong2": "Zil Hijjah",
   "wrong3": "Muharram",
   "category": "General",
   "min_level": 1,
   "coins": "",
   "explanation": ""
  },
  {
   "id": "q30",
   "active": true,
   "question": "Eid-ul-Adha kis nabi ki qurbani ki yaad mein manai jati hai?",
   "correct": "Hazrat Ibrahim (AS)",
   "wrong1": "Hazrat Nuh (AS)",
   "wrong2": "Hazrat Yaqub (AS)",
   "wrong3": "Hazrat Musa (AS)",
   "category": "General",
   "min_level": 1,
   "coins": "",
   "explanation": ""
  },
  {
   "id": "q31",
   "active": true,
   "question": "Shab-e-Qadr kis mahine mein aati hai?",
   "correct": "Ramadan",
   "wrong1": "Rajab",
   "wrong2": "Shaban",
   "wrong3": "Zil Qad",
   "category": "General",
   "min_level": 1,
   "coins": "",
   "explanation": ""
  },
  {
   "id": "q32",
   "active": true,
   "question": "Wudu mein sab se pehle kya dhoya jata hai?",
   "correct": "Hath",
   "wrong1": "Chehra",
   "wrong2": "Paon",
   "wrong3": "Sar ka masah",
   "category": "General",
   "min_level": 1,
   "coins": "",
   "explanation": ""
  },
  {
   "id": "q33",
   "active": true,
   "question": "Muslim ke liye qibla kis taraf hai?",
   "correct": "Kaaba (Makkah)",
   "wrong1": "Masjid-e-Aqsa",
   "wrong2": "Masjid-e-Nabawi",
   "wrong3": "Mount Sinai",
   "category": "General",
   "min_level": 1,
   "coins": "",
   "explanation": ""
  },
  {
   "id": "q34",
   "active": true,
   "question": "Tayammum kis cheez se kiya jata hai?",
   "correct": "Paak mitti se",
   "wrong1": "Namak se",
   "wrong2": "Aag se",
   "wrong3": "Hawa se",
   "category": "General",
   "min_level": 1,
   "coins": "",
   "explanation": ""
  },
  {
   "id": "q35",
   "active": true,
   "question": "Hazrat Yusuf (AS) ko kis ne kuen mein dala?",
   "correct": "Apne bhaiyon ne",
   "wrong1": "Doston ne",
   "wrong2": "Dushmanon ne",
   "wrong3": "Badshah ne",
   "category": "General",
   "min_level": 1,
   "coins": "",
   "explanation": ""
  },
  {
   "id": "q36",
   "active": true,
   "question": "Sahaba mein 'Siddique' ka laqab kis ko mila?",
   "correct": "Hazrat Abu Bakr (RA)",
   "wrong1": "Hazrat Umar (RA)",
   "wrong2": "Hazrat Ali (RA)",
   "wrong3": "Hazrat Bilal (RA)",
   "category": "General",
   "min_level": 1,
   "coins": "",
   "explanation": ""
  },
  {
   "id": "q37",
   "active": true,
   "question": "'Farooq' ka laqab kis sahabi ko mila?",
   "correct": "Hazrat Umar (RA)",
   "wrong1": "Hazrat Usman (RA)",
   "wrong2": "Hazrat Khalid (RA)",
   "wrong3": "Hazrat Hamza (RA)",
   "category": "General",
   "min_level": 1,
   "coins": "",
   "explanation": ""
  },
  {
   "id": "q38",
   "active": true,
   "question": "Pehle muazzin-e-Islam kaun the?",
   "correct": "Hazrat Bilal (RA)",
   "wrong1": "Hazrat Abu Zar (RA)",
   "wrong2": "Hazrat Salman (RA)",
   "wrong3": "Hazrat Anas (RA)",
   "category": "General",
   "min_level": 1,
   "coins": "",
   "explanation": ""
  },
  {
   "id": "q39",
   "active": true,
   "question": "Islamic calendar (Hijri) ka pehla mahina kaun sa hai?",
   "correct": "Muharram",
   "wrong1": "Ramadan",
   "wrong2": "Rajab",
   "wrong3": "Safar",
   "category": "General",
   "min_level": 1,
   "coins": "",
   "explanation": ""
  },
  {
   "id": "q40",
   "active": true,
   "question": "Surah Al-Fatiha mein kitni ayaat hain?",
   "correct": "7",
   "wrong1": "5",
   "wrong2": "6",
   "wrong3": "10",
   "category": "General",
   "min_level": 1,
   "coins": "",
   "explanation": ""
  },
  {
   "id": "q41",
   "active": true,
   "question": "Ayat-ul-Kursi kis surat mein hai?",
   "correct": "Surah Al-Baqarah",
   "wrong1": "Surah Al-Imran",
   "wrong2": "Surah Yaseen",
   "wrong3": "Surah Al-Mulk",
   "category": "General",
   "min_level": 1,
   "coins": "",
   "explanation": ""
  },
  {
   "id": "q42",
   "active": true,
   "question": "Rozedar roza kis waqt khulta (iftar karta) hai?",
   "correct": "Ghuroob-e-aftab par",
   "wrong1": "Zuhr par",
   "wrong2": "Asr par",
   "wrong3": "Isha par",
   "category": "General",
   "min_level": 1,
   "coins": "",
   "explanation": ""
  }
 ],
 "config": [
  [
   "app_title",
   "Islamic Quiz",
   "App ka naam (top par)"
  ],
  [
   "app_subtitle",
   "Apna Islamic ilm azmayein",
   "Naam ke niche chhota text"
  ],
  [
   "welcome_title",
   "Bismillah!",
   "Start screen ka heading"
  ],
  [
   "welcome_text",
   "Har sahi jawab par coins milenge. Coins se level up hoga. Har sawal ke liye limited waqt hai!",
   "Start screen ka text"
  ],
  [
   "start_button_text",
   "▶ Quiz Shuru Karein",
   "Start button ka text"
  ],
  [
   "correct_message",
   "Sahi Jawab! ✅",
   "Sahi jawab par dikhne wala message"
  ],
  [
   "wrong_title",
   "Galat Jawab!",
   "Galat jawab ke popup ka heading"
  ],
  [
   "wrong_text",
   "Sahi jawab hai:",
   "Galat jawab popup mein sahi jawab se pehle ka text"
  ],
  [
   "timeout_title",
   "Waqt Khatam!",
   "Time khatam hone par popup ka heading"
  ],
  [
   "next_button_text",
   "Agla Sawal ➜",
   "Popup ke Next button ka text"
  ],
  [
   "level_up_title",
   "Mubarak! Level Up!",
   "Level up popup ka heading"
  ],
  [
   "level_up_text",
   "MashaAllah! Aap agle level par pohanch gaye.",
   "Level up popup ka text"
  ],
  [
   "coins_per_correct",
   5,
   "Har sahi jawab par coins"
  ],
  [
   "coins_per_ad",
   5,
   "Rewarded ad dekhne par coins"
  ],
  [
   "coins_per_level",
   25,
   "Kitne coins par level badhe"
  ],
  [
   "question_time_seconds",
   15,
   "Har sawal ka timer (seconds)"
  ],
  [
   "next_delay_ms",
   1500,
   "Sahi jawab ke baad agle sawal tak intezar (milliseconds)"
  ],
  [
   "ads_enabled",
   true,
   "TRUE/FALSE - saare ads on/off"
  ],
  [
   "banner_enabled",
   true,
   "TRUE/FALSE - banner ad on/off"
  ],
  [
   "test_ads",
   false,
   "TRUE = Google ke test ads (testing ke liye), FALSE = asli ads"
  ],
  [
   "ad_button_text",
   "🎁 Daily Reward / Watch Ad for Coins",
   "Ad button ka text"
  ],
  [
   "ad_daily_limit",
   0,
   "Ek din mein max ads (0 = unlimited)"
  ],
  [
   "voice_enabled",
   true,
   "TRUE/FALSE - awaaz (sirf sahi/galat jawab bolti hai)"
  ],
  [
   "voice_correct_text",
   "Sahi jawab",
   "Sahi jawab par awaaz mein ye bola jayega"
  ],
  [
   "voice_wrong_text",
   "Galat jawab",
   "Galat jawab ya time khatam par awaaz mein ye bola jayega"
  ],
  [
   "voice_lang",
   "hi-IN",
   "Awaaz ki zubaan (hi-IN, ur-PK, en-US)"
  ],
  [
   "voice_rate",
   0.9,
   "Awaaz ki raftaar (0.5 se 1.5)"
  ],
  [
   "announcement",
   "",
   "Top par ek khaas ittela (khali = nahi dikhega)"
  ],
  [
   "boxes_title",
   "✨ Khaas Cheezein",
   "Boxes wale hisse ka heading (khali = heading nahi)"
  ],
  [
   "color_green",
   "#0b5d3b",
   "Rang: main green"
  ],
  [
   "color_green_dark",
   "#06402b",
   "Rang: gehra green"
  ],
  [
   "color_green_light",
   "#14804f",
   "Rang: halka green"
  ],
  [
   "color_gold",
   "#d4af37",
   "Rang: gold"
  ],
  [
   "color_gold_light",
   "#f3d77a",
   "Rang: halka gold"
  ],
  [
   "color_cream",
   "#fff8e1",
   "Rang: cream text"
  ],
  [
   "color_red",
   "#c0392b",
   "Rang: ghalat jawab ka laal"
  ]
 ],
 "boxes": [
  {
   "id": "welcome",
   "active": true,
   "order": 1,
   "type": "info",
   "icon": "🕌",
   "title": "Khush Aamdeed",
   "body": "Is box ko Google Sheet ke 'Boxes' tab se badal sakte hain.",
   "button_text": "",
   "url": "",
   "coins": "",
   "image_url": "",
   "bg_color": "",
   "text_color": ""
  },
  {
   "id": "bonus1",
   "active": true,
   "order": 2,
   "type": "reward",
   "icon": "🎁",
   "title": "Rozana Bonus",
   "body": "Har 24 ghante mein ek baar free coins hasil karein.",
   "button_text": "Coins Lein",
   "url": "",
   "coins": 10,
   "image_url": "",
   "bg_color": "",
   "text_color": ""
  },
  {
   "id": "share1",
   "active": false,
   "order": 3,
   "type": "link",
   "icon": "🔗",
   "title": "Hamara Page",
   "body": "Hamein follow karein.",
   "button_text": "Kholein",
   "url": "https://example.com",
   "coins": "",
   "image_url": "",
   "bg_color": "",
   "text_color": ""
  }
 ]
};

/* ------------------------------ API ------------------------------ */

function doGet(e) {
  var out;
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    out = {
      ok: true,
      version: new Date().getTime(),
      config: readConfig_(ss),
      questions: readRows_(ss, TABS.questions),
      boxes: readRows_(ss, TABS.boxes)
    };
  } catch (err) {
    out = { ok: false, error: String(err) };
  }
  return ContentService.createTextOutput(JSON.stringify(out)).setMimeType(ContentService.MimeType.JSON);
}

function readRows_(ss, tabName) {
  var sh = ss.getSheetByName(tabName);
  if (!sh || sh.getLastRow() < 2) return [];
  var values = sh.getRange(1, 1, sh.getLastRow(), sh.getLastColumn()).getValues();
  var headers = values[0].map(function (h) { return String(h).trim().toLowerCase(); });
  var rows = [];
  for (var r = 1; r < values.length; r++) {
    var row = values[r];
    var empty = row.every(function (c) { return c === '' || c === null; });
    if (empty) continue;
    var obj = {};
    for (var c = 0; c < headers.length; c++) {
      if (!headers[c]) continue;
      var v = row[c];
      if (v instanceof Date) v = v.toISOString();
      obj[headers[c]] = v;
    }
    rows.push(obj);
  }
  return rows;
}

function readConfig_(ss) {
  var sh = ss.getSheetByName(TABS.config);
  var cfg = {};
  if (!sh || sh.getLastRow() < 2) return cfg;
  var values = sh.getRange(2, 1, sh.getLastRow() - 1, 2).getValues();
  values.forEach(function (row) {
    var key = String(row[0]).trim();
    if (key) cfg[key] = row[1];
  });
  return cfg;
}

/* --------------------------- Sheet setup --------------------------- */

function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu('Islamic Quiz')
    .addItem('Sheet setup (pehli baar)', 'setupSheet')
    .addItem('App link (API URL) dikhao', 'showApiUrl')
    .addToUi();
}

function showApiUrl() {
  var url = ScriptApp.getService().getUrl();
  var msg = url
    ? 'Ye URL app ki www/config.js mein SHEET_API_URL mein paste karein:\n\n' + url
    : 'Abhi deploy nahi hua. Extensions > Apps Script > Deploy > New deployment > Web app (Anyone) karein.';
  SpreadsheetApp.getUi().alert(msg);
}

function setupSheet() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();

  // ---- Questions ----
  var q = getOrCreate_(ss, TABS.questions);
  if (q.getLastRow() < 2) {
    q.clear();
    q.getRange(1, 1, 1, Q_HEADERS.length).setValues([Q_HEADERS]);
    var qRows = SEED.questions.map(function (s) {
      return Q_HEADERS.map(function (h) { return s[h] === undefined ? '' : s[h]; });
    });
    q.getRange(2, 1, qRows.length, Q_HEADERS.length).setValues(qRows);
  }
  styleHeader_(q, Q_HEADERS.length);
  q.getRange(2, 2, 1000, 1).insertCheckboxes();
  q.setColumnWidth(1, 70); q.setColumnWidth(2, 60); q.setColumnWidth(3, 380);
  for (var c = 4; c <= 7; c++) q.setColumnWidth(c, 180);
  q.setColumnWidth(8, 100); q.setColumnWidth(11, 260);

  // ---- Config ----
  var cf = getOrCreate_(ss, TABS.config);
  if (cf.getLastRow() < 2) {
    cf.clear();
    cf.getRange(1, 1, 1, 3).setValues([CONFIG_HEADERS]);
    var cRows = SEED.config.map(function (s) { return [s[0], s[1], s[2]]; });
    cf.getRange(2, 1, cRows.length, 3).setValues(cRows);
  }
  styleHeader_(cf, 3);
  cf.setColumnWidth(1, 190); cf.setColumnWidth(2, 380); cf.setColumnWidth(3, 420);

  // ---- Boxes ----
  var bx = getOrCreate_(ss, TABS.boxes);
  if (bx.getLastRow() < 2) {
    bx.clear();
    bx.getRange(1, 1, 1, BOX_HEADERS.length).setValues([BOX_HEADERS]);
    var bRows = SEED.boxes.map(function (s) {
      return BOX_HEADERS.map(function (h) { return s[h] === undefined ? '' : s[h]; });
    });
    bx.getRange(2, 1, bRows.length, BOX_HEADERS.length).setValues(bRows);
  }
  styleHeader_(bx, BOX_HEADERS.length);
  bx.getRange(2, 2, 200, 1).insertCheckboxes();
  bx.getRange(2, 4, 200, 1).setDataValidation(
    SpreadsheetApp.newDataValidation().requireValueInList(['info', 'link', 'reward', 'image'], true).setAllowInvalid(false).build()
  );
  bx.setColumnWidth(6, 180); bx.setColumnWidth(7, 320); bx.setColumnWidth(9, 220);

  // default empty "Sheet1" hatao
  var def = ss.getSheetByName('Sheet1') || ss.getSheetByName('Sheet 1');
  if (def && ss.getSheets().length > 1 && def.getLastRow() === 0) ss.deleteSheet(def);

  ss.setActiveSheet(q);
  SpreadsheetApp.getUi().alert('Sheet tayyar hai!\n\nAb Deploy > New deployment > Web app (Who has access: Anyone) karein aur URL app ki config.js mein lagayein.');
}

function getOrCreate_(ss, name) {
  return ss.getSheetByName(name) || ss.insertSheet(name);
}

function styleHeader_(sh, cols) {
  sh.setFrozenRows(1);
  sh.getRange(1, 1, 1, cols)
    .setFontWeight('bold').setBackground('#0b5d3b').setFontColor('#f3d77a');
}
