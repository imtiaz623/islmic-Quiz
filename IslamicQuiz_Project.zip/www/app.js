"use strict";
/* ============================================================
   ISLAMIC QUIZ - app.js
   Data (sawal, config, boxes) Google Sheet se aata hai (Apps Script API).
   Offline ho to pichla cache, aur cache bhi na ho to fallback.js ke andar ke sawal.
   ============================================================ */

const APP = window.APP_CONFIG || {};
const ADMOB = APP.ADMOB || {};
const $ = id => document.getElementById(id);

/* ------------------------------------------------------------
   1. DEFAULT SETTINGS (Sheet ke Config tab se override hoti hain)
   ------------------------------------------------------------ */
const DEFAULTS = {
  app_title: "Islamic Quiz",
  app_subtitle: "Apna Islamic ilm azmayein",
  welcome_title: "Bismillah!",
  welcome_text: "Har sahi jawab par coins milenge. Coins se level up hoga.",
  start_button_text: "▶ Quiz Shuru Karein",
  correct_message: "Sahi Jawab! ✅",
  wrong_title: "Galat Jawab!",
  wrong_text: "Sahi jawab hai:",
  timeout_title: "Waqt Khatam!",
  next_button_text: "Agla Sawal ➜",
  level_up_title: "Mubarak! Level Up!",
  level_up_text: "MashaAllah! Aap agle level par pohanch gaye.",
  coins_per_correct: 5,
  coins_per_ad: 5,
  coins_per_level: 25,
  question_time_seconds: 15,
  next_delay_ms: 1500,
  ads_enabled: true,
  banner_enabled: true,
  test_ads: false,
  ad_button_text: "🎁 Daily Reward / Watch Ad for Coins",
  ad_daily_limit: 0,
  voice_enabled: true,
  voice_correct_text: "Sahi jawab",
  voice_wrong_text: "Galat jawab",
  voice_lang: "hi-IN",
  voice_rate: 0.9,
  announcement: "",
  boxes_title: "",
  color_green: "#0b5d3b",
  color_green_dark: "#06402b",
  color_green_light: "#14804f",
  color_gold: "#d4af37",
  color_gold_light: "#f3d77a",
  color_cream: "#fff8e1",
  color_red: "#c0392b"
};

let CFG = Object.assign({}, DEFAULTS);   // abhi ki active settings

/* ------------------------------------------------------------
   2. HELPERS
   ------------------------------------------------------------ */
function str(v) { return v === undefined || v === null ? "" : String(v).trim(); }
function num(v, def, min, max) {
  const n = parseFloat(str(v).replace(",", "."));
  let r = isFinite(n) ? n : def;
  if (min !== undefined) r = Math.max(min, r);
  if (max !== undefined) r = Math.min(max, r);
  return r;
}
function bool(v, def) {
  if (v === true || v === false) return v;
  const s = str(v).toLowerCase();
  if (s === "") return def;
  if (["true", "yes", "1", "y", "haan", "ha", "on"].includes(s)) return true;
  if (["false", "no", "0", "n", "nahi", "off"].includes(s)) return false;
  return def;
}
function hash(s) {
  let h = 5381;
  for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0;
  return (h >>> 0).toString(36);
}
function shuffle(arr) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
function isHttpUrl(u) { return /^https?:\/\/[^\s]+$/i.test(u); }
function safeColor(v, def) {
  v = str(v);
  if (!v) return def;
  try { if (window.CSS && CSS.supports && CSS.supports("color", v)) return v; } catch (e) {}
  return def;
}
function todayKey() {
  const d = new Date();
  return d.getFullYear() + "-" + (d.getMonth() + 1) + "-" + d.getDate();
}
function toast(msg) {
  const t = $("toast");
  t.textContent = msg;
  t.classList.add("show");
  clearTimeout(toast._t);
  toast._t = setTimeout(() => t.classList.remove("show"), 2400);
}
const isNative = () => !!(window.Capacitor && Capacitor.isNativePlatform && Capacitor.isNativePlatform());
const plugin = name => (window.Capacitor && Capacitor.Plugins && Capacitor.Plugins[name]) || null;

/* ------------------------------------------------------------
   3. SAVE DATA (coins, awaaz, claims, ad count)
   ------------------------------------------------------------ */
const SAVE_KEY = "islamicQuizSave";
const CACHE_KEY = "islamicQuizSheetCache";
const save = { coins: 0, soundOn: true, claims: {}, adDay: "", adCount: 0 };

function loadSave() {
  try {
    const s = JSON.parse(localStorage.getItem(SAVE_KEY) || "{}");
    if (typeof s.coins === "number" && isFinite(s.coins)) save.coins = Math.max(0, Math.floor(s.coins));
    if (typeof s.soundOn === "boolean") save.soundOn = s.soundOn;
    if (s.claims && typeof s.claims === "object") save.claims = s.claims;
    if (typeof s.adDay === "string") save.adDay = s.adDay;
    if (typeof s.adCount === "number") save.adCount = s.adCount;
  } catch (e) {}
}
function persist() {
  try { localStorage.setItem(SAVE_KEY, JSON.stringify(save)); } catch (e) {}
}

/* ------------------------------------------------------------
   4. DATA LAYER  (Sheet -> normalize -> cache)
   ------------------------------------------------------------ */
const Data = {
  questions: new Map(),    // id -> question
  boxes: [],
  config: {},
  loadedOnce: false,
  live: false,
  fetching: false,

  normalizeQuestion(r) {
    const question = str(r.question);
    const correct = str(r.correct);
    if (!question || !correct) return null;
    if (!bool(r.active, true)) return null;
    const wrongs = [r.wrong1, r.wrong2, r.wrong3].map(str).filter(Boolean);
    const options = [];
    [correct].concat(wrongs).forEach(o => { if (!options.includes(o)) options.push(o); });
    if (options.length < 2) return null;
    const id = str(r.id) ? "id:" + str(r.id) : "h:" + hash(question + "|" + correct);
    return {
      id, question, correct,
      wrongs: options.filter(o => o !== correct),
      category: str(r.category),
      minLevel: Math.max(1, Math.floor(num(r.min_level, 1))),
      coins: str(r.coins) === "" ? null : Math.max(0, Math.floor(num(r.coins, 0))),
      explanation: str(r.explanation)
    };
  },

  normalizeBox(r) {
    if (!bool(r.active, true)) return null;
    const title = str(r.title), body = str(r.body);
    if (!title && !body && !str(r.image_url)) return null;
    let type = str(r.type).toLowerCase();
    if (!["info", "link", "reward", "image"].includes(type)) type = "info";
    return {
      id: str(r.id) || "b:" + hash(title + body),
      order: num(r.order, 999),
      type, icon: str(r.icon), title, body,
      buttonText: str(r.button_text), url: str(r.url),
      coins: Math.max(0, Math.floor(num(r.coins, 0))),
      imageUrl: str(r.image_url), bg: str(r.bg_color), fg: str(r.text_color)
    };
  },

  /* Sheet ya cache wale raw data ko app mein laga do. Return: nayi aayi hui question ids */
  apply(raw) {
    const cfg = Object.assign({}, DEFAULTS);
    const rc = raw.config || {};
    Object.keys(rc).forEach(k => {
      const v = rc[k];
      if (k in DEFAULTS && (typeof v === "boolean" || typeof v === "number" || str(v) !== "" || k === "announcement" || k === "boxes_title")) cfg[k] = v;
    });
    CFG = cfg;

    const prevIds = new Set(this.questions.keys());
    const map = new Map();
    (raw.questions || []).forEach(r => { const q = this.normalizeQuestion(r); if (q) map.set(q.id, q); });
    if (map.size === 0 && this.questions.size > 0) {
      // Sheet khali/ghalat aayi to purane sawal na khoyein
    } else {
      this.questions = map;
    }
    this.boxes = (raw.boxes || []).map(r => this.normalizeBox(r)).filter(Boolean).sort((a, b) => a.order - b.order);
    this.config = cfg;
    const fresh = [];
    if (this.loadedOnce) this.questions.forEach((q, id) => { if (!prevIds.has(id)) fresh.push(id); });
    this.loadedOnce = true;
    return fresh;
  },

  readCache() {
    try { const c = JSON.parse(localStorage.getItem(CACHE_KEY) || "null"); if (c && c.questions) return c; } catch (e) {}
    return null;
  },
  writeCache(raw) {
    try { localStorage.setItem(CACHE_KEY, JSON.stringify({ config: raw.config, questions: raw.questions, boxes: raw.boxes, at: Date.now() })); } catch (e) {}
  },

  async fetchRemote() {
    const url = str(APP.SHEET_API_URL);
    if (!url) return null;
    const full = url + (url.indexOf("?") >= 0 ? "&" : "?") + "t=" + Date.now();
    const req = fetch(full, { cache: "no-store" }).then(r => {
      if (!r.ok) throw new Error("HTTP " + r.status);
      return r.json();
    });
    const timeout = new Promise((_, rej) => setTimeout(() => rej(new Error("timeout")), 15000));
    const json = await Promise.race([req, timeout]);
    if (!json || json.ok !== true) throw new Error((json && json.error) || "bad response");
    return json;
  },

  /* Sheet se naya data lo. silent=true ho to sirf zaroorat par toast */
  async refresh(manual) {
    if (this.fetching) return;
    this.fetching = true;
    $("refreshBtn").classList.add("spin");
    try {
      const json = await this.fetchRemote();
      if (!json) { setSync(false, "sheet link nahi"); if (manual) toast("config.js mein SHEET_API_URL set nahi hai"); return; }
      const fresh = this.apply(json);
      this.writeCache(json);
      this.live = true;
      setSync(true, "live");
      onDataChanged(fresh);
      if (manual) toast("✅ Sheet se naya data mil gaya");
    } catch (e) {
      this.live = false;
      setSync(false, "offline");
      if (manual) toast("Sheet tak nahi pahunch sake. Internet check karein.");
    } finally {
      this.fetching = false;
      $("refreshBtn").classList.remove("spin");
    }
  }
};

function setSync(live, text) {
  const el = $("syncState");
  el.textContent = text;
  el.classList.toggle("live", live);
}

/* ------------------------------------------------------------
   5. UI: Config lagana
   ------------------------------------------------------------ */
const levelSize = () => Math.floor(num(CFG.coins_per_level, 25, 1, 100000));
const levelFromCoins = c => Math.floor(c / levelSize()) + 1;
const timeLimit = () => Math.floor(num(CFG.question_time_seconds, 15, 3, 300));

function applyConfig() {
  const root = document.documentElement.style;
  root.setProperty("--green", safeColor(CFG.color_green, DEFAULTS.color_green));
  root.setProperty("--green-dark", safeColor(CFG.color_green_dark, DEFAULTS.color_green_dark));
  root.setProperty("--green-light", safeColor(CFG.color_green_light, DEFAULTS.color_green_light));
  root.setProperty("--gold", safeColor(CFG.color_gold, DEFAULTS.color_gold));
  root.setProperty("--gold-light", safeColor(CFG.color_gold_light, DEFAULTS.color_gold_light));
  root.setProperty("--cream", safeColor(CFG.color_cream, DEFAULTS.color_cream));
  root.setProperty("--red", safeColor(CFG.color_red, DEFAULTS.color_red));

  $("appTitle").textContent = "☪ " + str(CFG.app_title) + " ☪";
  document.title = str(CFG.app_title) || "Islamic Quiz";
  $("appSubtitle").textContent = str(CFG.app_subtitle);
  $("welcomeTitle").textContent = str(CFG.welcome_title);
  $("welcomeText").textContent = str(CFG.welcome_text);
  $("startBtn").textContent = str(CFG.start_button_text);
  $("nextBtn").textContent = str(CFG.next_button_text);
  $("levelTitle").textContent = str(CFG.level_up_title);
  $("levelText").textContent = str(CFG.level_up_text);
  $("adBtn").textContent = str(CFG.ad_button_text);

  const ann = str(CFG.announcement);
  $("announce").style.display = ann ? "block" : "none";
  $("announce").textContent = ann;

  const bt = str(CFG.boxes_title);
  $("boxesTitle").style.display = bt && Data.boxes.length ? "block" : "none";
  $("boxesTitle").textContent = bt;

  $("adBtn").style.display = bool(CFG.ads_enabled, true) ? "" : "none";
  syncSoundBtn();
  updateHUD();
  if (!Quiz.active) $("timerNum").textContent = timeLimit();
}

function updateHUD() {
  const size = levelSize();
  const lvl = levelFromCoins(save.coins);
  const inLevel = save.coins % size;
  $("coins").textContent = save.coins;
  $("level").textContent = lvl;
  $("progLeft").textContent = "Level " + lvl;
  $("progRight").textContent = inLevel + " / " + size;
  $("progBar").style.width = (inLevel / size * 100) + "%";
}

function syncSoundBtn() {
  const voiceAllowed = bool(CFG.voice_enabled, true);
  $("soundBtn").style.display = voiceAllowed ? "" : "none";
  $("soundBtn").textContent = save.soundOn ? "🔊 Awaaz: ON" : "🔇 Awaaz: OFF";
}

function onDataChanged(freshIds) {
  applyConfig();
  Quiz.onPoolChanged(freshIds);
  Boxes.render();
  Ads.onConfigChanged();
}

/* ------------------------------------------------------------
   6. VOICE - sirf "Sahi jawab" / "Galat jawab" bolti hai
   ------------------------------------------------------------ */
const Voice = {
  say(kind) {
    if (!save.soundOn || !bool(CFG.voice_enabled, true)) return;
    const text = str(kind === "correct" ? CFG.voice_correct_text : CFG.voice_wrong_text);
    if (!text) return;
    const lang = str(CFG.voice_lang) || "hi-IN";
    const rate = num(CFG.voice_rate, 0.9, 0.3, 2);
    this.stop();
    const tts = plugin("TextToSpeech");
    if (isNative() && tts) {
      tts.speak({ text, lang, rate, pitch: 1, volume: 1, queueStrategy: 0 }).catch(() => this.webSpeak(text, lang, rate));
    } else {
      this.webSpeak(text, lang, rate);
    }
  },
  webSpeak(text, lang, rate) {
    if (!("speechSynthesis" in window)) return;
    try {
      const u = new SpeechSynthesisUtterance(text);
      u.lang = lang; u.rate = rate;
      const voices = speechSynthesis.getVoices();
      const v = voices.find(x => x.lang && x.lang.toLowerCase() === lang.toLowerCase()) ||
                voices.find(x => x.lang && x.lang.toLowerCase().indexOf(lang.slice(0, 2).toLowerCase()) === 0);
      if (v) u.voice = v;
      speechSynthesis.speak(u);
    } catch (e) {}
  },
  stop() {
    try {
      const tts = plugin("TextToSpeech");
      if (isNative() && tts) tts.stop().catch(() => {});
      if ("speechSynthesis" in window) speechSynthesis.cancel();
    } catch (e) {}
  }
};

/* ------------------------------------------------------------
   7. TIMER (har sawal par, default 15 second)
   ------------------------------------------------------------ */
const Timer = {
  total: 15000, remaining: 15000, deadline: 0, iv: null, running: false, holds: 0, onTimeout: null,

  start(seconds, onTimeout) {
    this.stop();
    this.total = seconds * 1000;
    this.remaining = this.total;
    this.onTimeout = onTimeout;
    this.running = true;
    this.holds = 0;
    this.deadline = Date.now() + this.remaining;
    this.iv = setInterval(() => this.tick(), 100);
    this.render();
  },
  tick() {
    if (!this.running || this.holds > 0) return;
    this.remaining = this.deadline - Date.now();
    if (this.remaining <= 0) {
      this.remaining = 0;
      this.render();
      const cb = this.onTimeout;
      this.stop();
      if (cb) cb();
      return;
    }
    this.render();
  },
  /* Ad / popup / app background ke dauran timer rok do */
  hold() {
    if (!this.running) return false;
    if (this.holds === 0) this.remaining = Math.max(0, this.deadline - Date.now());
    this.holds++;
    return true;
  },
  release() {
    if (!this.running || this.holds === 0) return;
    this.holds--;
    if (this.holds === 0) this.deadline = Date.now() + this.remaining;
  },
  stop() {
    if (this.iv) clearInterval(this.iv);
    this.iv = null; this.running = false; this.holds = 0;
  },
  render() {
    const secs = Math.ceil(this.remaining / 1000);
    $("timerNum").textContent = secs;
    $("timerFill").style.transform = "scaleX(" + Math.max(0, this.remaining / this.total) + ")";
    $("timer").classList.toggle("low", secs <= 5);
  }
};

/* ------------------------------------------------------------
   8. EFFECTS + COINS
   ------------------------------------------------------------ */
function floatText(t) {
  const el = document.createElement("div");
  el.className = "float"; el.textContent = t;
  document.body.appendChild(el);
  setTimeout(() => el.remove(), 1200);
}
function confetti(n) {
  const colors = ["#d4af37", "#f3d77a", "#27ae60", "#ffffff", "#14804f"];
  for (let i = 0; i < n; i++) {
    const c = document.createElement("div");
    c.className = "confetti";
    c.style.left = Math.random() * 100 + "vw";
    c.style.background = colors[Math.floor(Math.random() * colors.length)];
    c.style.animationDuration = (1.6 + Math.random() * 1.6) + "s";
    c.style.animationDelay = (Math.random() * 0.4) + "s";
    document.body.appendChild(c);
    setTimeout(() => c.remove(), 3800);
  }
}

/* Overlay kholne par timer ruk jata hai, band hone par chalta hai */
const Overlay = {
  open(id, holdTimer) {
    const el = $(id);
    if (el.classList.contains("show")) return;
    el.classList.add("show");
    el._held = holdTimer ? Timer.hold() : false;
  },
  close(id) {
    const el = $(id);
    if (!el.classList.contains("show")) return;
    el.classList.remove("show");
    if (el._held) { el._held = false; Timer.release(); }
  }
};

/* coins jodo. Return true agar level up hua */
function addCoins(n, opts) {
  opts = opts || {};
  if (!(n > 0)) return false;
  const before = levelFromCoins(save.coins);
  save.coins += n;
  const after = levelFromCoins(save.coins);
  persist();
  updateHUD();
  floatText("+" + n + " 🪙");
  if (after > before) {
    setTimeout(() => {
      $("newLevel").textContent = after;
      Overlay.open("levelOverlay", !opts.noHold);
      confetti(40);
    }, 500);
    return true;
  }
  return false;
}

/* ------------------------------------------------------------
   9. QUIZ
   ------------------------------------------------------------ */
const Quiz = {
  active: false, locked: true, current: null, options: [], count: 0,
  deck: [], lastId: null, pendingNext: false, timeoutHandle: null,

  eligibleIds() {
    const lvl = levelFromCoins(save.coins);
    let ids = [];
    Data.questions.forEach((q, id) => { if (q.minLevel <= lvl) ids.push(id); });
    if (!ids.length) ids = Array.from(Data.questions.keys());
    return ids;
  },

  /* Sheet update hone par: naye sawal agle number par aayenge */
  onPoolChanged(freshIds) {
    if (!this.active) { this.deck = []; return; }
    this.deck = this.deck.filter(id => Data.questions.has(id));
    if (freshIds && freshIds.length) {
      const elig = new Set(this.eligibleIds());
      shuffle(freshIds.filter(id => elig.has(id))).forEach(id => {
        this.deck = this.deck.filter(x => x !== id);
        this.deck.push(id);                 // pop() end se uthata hai => agla sawal
      });
      if (this.active) toast("🆕 Naye sawal add hue hain!");
    }
  },

  next() {
    if (!Data.questions.size) return null;
    const lvl = levelFromCoins(save.coins);
    for (let guard = 0; guard < 3; guard++) {
      while (this.deck.length) {
        const id = this.deck.pop();
        const q = Data.questions.get(id);
        if (q && (q.minLevel <= lvl || guard > 0)) return q;
      }
      let ids = this.eligibleIds();
      if (ids.length > 1) ids = ids.filter(id => id !== this.lastId);
      this.deck = shuffle(ids);
    }
    return Data.questions.values().next().value;
  },

  start() {
    this.active = true;
    $("startCard").style.display = "none";
    $("quizCard").style.display = "block";
    $("actions").style.display = "flex";
    this.show();
  },

  show() {
    clearTimeout(this.timeoutHandle);
    const q = this.next();
    if (!q) { toast("Abhi koi sawal mojood nahi."); return; }
    this.current = q;
    this.lastId = q.id;
    this.locked = false;
    this.count++;
    $("qnum").textContent = "Sawal " + this.count;
    const cat = $("qcat");
    cat.style.display = q.category ? "" : "none";
    cat.textContent = q.category;
    $("question").textContent = q.question;
    $("okmsg").textContent = "";

    const opts = shuffle([q.correct].concat(q.wrongs));
    this.options = opts;
    const box = $("options");
    box.innerHTML = "";
    const letters = ["A", "B", "C", "D"];
    opts.forEach((text, i) => {
      const b = document.createElement("button");
      b.className = "opt"; b.type = "button"; b.dataset.value = text;
      const badge = document.createElement("span"); badge.className = "badge"; badge.textContent = letters[i];
      const label = document.createElement("span"); label.textContent = text;
      b.appendChild(badge); b.appendChild(label);
      b.addEventListener("click", () => this.answer(b, text));
      box.appendChild(b);
    });

    Timer.start(timeLimit(), () => this.timeUp());
    if (document.hidden) Timer.hold();
  },

  answer(btn, text) {
    if (this.locked) return;
    this.locked = true;
    Timer.stop();
    const q = this.current;
    const buttons = document.querySelectorAll(".opt");
    buttons.forEach(b => (b.disabled = true));

    if (text === q.correct) {
      btn.classList.add("correct");
      $("okmsg").textContent = str(CFG.correct_message);
      confetti(24);
      Voice.say("correct");
      const reward = q.coins !== null ? q.coins : Math.floor(num(CFG.coins_per_correct, 5, 0, 100000));
      const leveled = addCoins(reward, { noHold: true });
      if (leveled) this.pendingNext = true;
      else this.timeoutHandle = setTimeout(() => this.show(), num(CFG.next_delay_ms, 1500, 300, 10000));
    } else {
      btn.classList.add("wrong");
      this.showWrong(false);
    }
  },

  timeUp() {
    if (this.locked) return;
    this.locked = true;
    document.querySelectorAll(".opt").forEach(b => (b.disabled = true));
    this.showWrong(true);
  },

  showWrong(isTimeout) {
    const q = this.current;
    document.querySelectorAll(".opt").forEach(b => { b.disabled = true; if (b.dataset.value === q.correct) b.classList.add("correct"); });
    $("wrongIcon").textContent = isTimeout ? "⏰" : "❌";
    $("wrongTitle").textContent = str(isTimeout ? CFG.timeout_title : CFG.wrong_title);
    $("wrongLead").textContent = str(CFG.wrong_text);
    $("correctText").textContent = q.correct;
    $("explText").textContent = q.explanation;
    Voice.say("wrong");
    setTimeout(() => Overlay.open("wrongOverlay", false), 600);
  },

  afterWrongPopup() {
    Overlay.close("wrongOverlay");
    this.show();
  },

  afterLevelPopup() {
    Overlay.close("levelOverlay");
    if (this.pendingNext) { this.pendingNext = false; this.show(); }
  }
};

/* ------------------------------------------------------------
   10. BOXES (Sheet ke Boxes tab se)
   ------------------------------------------------------------ */
const Boxes = {
  render() {
    const wrap = $("boxes");
    wrap.innerHTML = "";
    Data.boxes.forEach(b => wrap.appendChild(this.build(b)));
    $("boxesTitle").style.display = str(CFG.boxes_title) && Data.boxes.length ? "block" : "none";
  },

  claimLeftMs(b) {
    const t = save.claims[b.id];
    if (!t) return 0;
    return Math.max(0, t + 24 * 3600 * 1000 - Date.now());
  },

  build(b) {
    const el = document.createElement("div");
    el.className = "box";
    if (b.bg) el.style.background = safeColor(b.bg, "");
    if (b.fg) el.style.color = safeColor(b.fg, "");

    if (b.icon) { const i = document.createElement("div"); i.className = "bicon"; i.textContent = b.icon; el.appendChild(i); }
    const body = document.createElement("div"); body.className = "bbody";
    if (b.title) { const h = document.createElement("h3"); h.textContent = b.title; if (b.fg) h.style.color = "inherit"; body.appendChild(h); }
    if (b.body) { const p = document.createElement("p"); p.textContent = b.body; body.appendChild(p); }
    if (b.type === "image" && isHttpUrl(b.imageUrl)) {
      const img = document.createElement("img");
      img.src = b.imageUrl; img.alt = b.title || ""; img.loading = "lazy";
      img.onerror = () => img.remove();
      body.appendChild(img);
    }

    if (b.type === "link" && isHttpUrl(b.url)) {
      const a = document.createElement("a");
      a.className = "btn btn-gold"; a.style.display = "block"; a.style.textAlign = "center"; a.style.textDecoration = "none";
      a.textContent = b.buttonText || "Kholein";
      a.href = b.url; a.target = "_blank"; a.rel = "noopener noreferrer";
      body.appendChild(a);
    }

    if (b.type === "reward" && b.coins > 0) {
      const btn = document.createElement("button");
      btn.className = "btn btn-gold"; btn.type = "button";
      const hint = document.createElement("div"); hint.className = "hint";
      const refresh = () => {
        const left = this.claimLeftMs(b);
        if (left > 0) {
          const h = Math.floor(left / 3600000), m = Math.ceil((left % 3600000) / 60000);
          btn.disabled = true;
          btn.textContent = "✔ Hasil kar liya";
          hint.textContent = "Agla reward " + h + " ghante " + (m % 60) + " minute baad.";
        } else {
          btn.disabled = false;
          btn.textContent = (b.buttonText || "Coins Lein") + " (+" + b.coins + " 🪙)";
          hint.textContent = "";
        }
      };
      btn.addEventListener("click", () => {
        if (this.claimLeftMs(b) > 0) return;
        save.claims[b.id] = Date.now();
        persist();
        addCoins(b.coins, { noHold: !Quiz.active || Quiz.locked });
        toast("🎉 " + b.coins + " coins mil gaye!");
        refresh();
      });
      refresh();
      body.appendChild(btn);
      body.appendChild(hint);
    }

    el.appendChild(body);
    return el;
  }
};

/* ------------------------------------------------------------
   11. ADS (AdMob)  - APK mein asli ads, browser mein mock
   ------------------------------------------------------------ */
const Ads = {
  inited: false,
  bannerShown: false,
  rewardBusy: false,

  testMode() { return bool(CFG.test_ads, false); },
  bannerId() { return this.testMode() ? ADMOB.TEST_BANNER_AD_UNIT_ID : ADMOB.BANNER_AD_UNIT_ID; },
  rewardId() { return this.testMode() ? ADMOB.TEST_REWARDED_AD_UNIT_ID : ADMOB.REWARDED_AD_UNIT_ID; },
  adsOn() { return bool(CFG.ads_enabled, true); },
  bannerOn() { return this.adsOn() && bool(CFG.banner_enabled, true); },

  async init() {
    const admob = plugin("AdMob");
    if (!isNative() || !admob) { this.onConfigChanged(); return; }
    try {
      // EU/UK users ke liye Google consent form (zaroori nahi to kuch nahi dikhta)
      try {
        const info = await admob.requestConsentInfo();
        if (info && info.isConsentFormAvailable && info.status === "REQUIRED") await admob.showConsentForm();
      } catch (e) { /* consent fail ho to bhi aage chalo */ }

      await admob.initialize({});
      this.inited = true;
      admob.addListener("bannerAdSizeChanged", size => {
        if (size && size.height) document.documentElement.style.setProperty("--banner-h", Math.ceil(size.height) + "px");
      });
      this.onConfigChanged();
    } catch (e) { console.warn("AdMob init fail:", e); }
  },

  /* Sheet mein ads_enabled / banner_enabled / test_ads badalne par */
  async onConfigChanged() {
    const admob = plugin("AdMob");
    const holder = $("bannerContainer");
    if (!isNative() || !admob) {
      // Browser: sirf dikhane ke liye mock banner
      if (this.bannerOn()) holder.innerHTML = '<div class="mock">📢 Banner Ad (Mock) — ' + this.bannerId() + "</div>";
      else { holder.innerHTML = ""; document.documentElement.style.setProperty("--banner-h", "0px"); }
      return;
    }
    if (!this.inited) return;
    const wantKey = this.bannerOn() ? this.bannerId() : "";
    if (wantKey === this._shownKey) return;
    try {
      if (this.bannerShown) { await admob.removeBanner(); this.bannerShown = false; }
      this._shownKey = wantKey;
      if (wantKey) {
        await admob.showBanner({ adId: wantKey, adSize: "ADAPTIVE_BANNER", position: "BOTTOM_CENTER", margin: 0, isTesting: this.testMode() });
        this.bannerShown = true;
      } else {
        document.documentElement.style.setProperty("--banner-h", "0px");
      }
    } catch (e) { console.warn("Banner fail:", e); this._shownKey = ""; }
  },

  limitReached() {
    const limit = Math.floor(num(CFG.ad_daily_limit, 0, 0, 1000));
    if (!limit) return false;
    if (save.adDay !== todayKey()) { save.adDay = todayKey(); save.adCount = 0; persist(); }
    return save.adCount >= limit;
  },
  countAd() {
    if (save.adDay !== todayKey()) { save.adDay = todayKey(); save.adCount = 0; }
    save.adCount++; persist();
  },

  /* Resolve: true = reward mila, false = nahi */
  showRewarded() {
    const admob = plugin("AdMob");
    if (isNative() && admob && this.inited) return this.showNativeRewarded(admob);
    return this.showMockRewarded();
  },

  async showNativeRewarded(admob) {
    const handles = [];
    let rewarded = false;
    try {
      await admob.prepareRewardVideoAd({ adId: this.rewardId(), isTesting: this.testMode() });
      const done = new Promise(resolve => {
        const guard = setTimeout(() => resolve(), 5 * 60 * 1000);
        const fin = () => { clearTimeout(guard); resolve(); };
        const on = (name, cb) => Promise.resolve(admob.addListener(name, cb)).then(h => handles.push(h)).catch(() => {});
        on("onRewardedVideoAdReward", () => { rewarded = true; });
        on("onRewardedVideoAdDismissed", fin);
        on("onRewardedVideoAdFailedToShow", fin);
      });
      await admob.showRewardVideoAd();
      await done;
    } catch (e) {
      console.warn("Rewarded fail:", e);
    } finally {
      handles.forEach(h => { try { if (h && h.remove) h.remove(); } catch (e) {} });
    }
    return rewarded;
  },

  showMockRewarded() {
    return new Promise(resolve => {
      const ov = $("adOverlay"), timer = $("adTimer"), btn = $("adClose"), msg = $("adMsg");
      let n = 5;
      timer.textContent = n; btn.disabled = true;
      msg.textContent = "Ad chal raha hai... (Test simulation)";
      ov.classList.add("show");
      const iv = setInterval(() => {
        n--; timer.textContent = Math.max(n, 0);
        if (n <= 0) { clearInterval(iv); btn.disabled = false; msg.textContent = "Ad mukammal! Reward le lein."; }
      }, 1000);
      btn.onclick = () => { clearInterval(iv); ov.classList.remove("show"); resolve(true); };
    });
  }
};

async function onAdButton() {
  if (Ads.rewardBusy) return;
  if (!Ads.adsOn()) { toast("Abhi ads band hain."); return; }
  if (Ads.limitReached()) { toast("Aaj ke ads ki hadd poori ho gayi. Kal dobara aayein."); return; }
  Ads.rewardBusy = true;
  const btn = $("adBtn");
  btn.disabled = true;
  Voice.stop();
  Timer.hold();                         // ad ke dauran sawal ka timer ruka rahe
  let ok = false;
  try { ok = await Ads.showRewarded(); } catch (e) { ok = false; }
  Timer.release();
  if (ok) {
    Ads.countAd();
    const coins = Math.floor(num(CFG.coins_per_ad, 5, 0, 100000));
    toast("🎉 Ad mukammal! " + coins + " coins mil gaye.");
    addCoins(coins);
    confetti(20);
  } else {
    toast("Ad abhi mojood nahi ya mukammal nahi hua. Thori der baad dobara koshish karein.");
  }
  btn.disabled = false;
  Ads.rewardBusy = false;
}

/* ------------------------------------------------------------
   12. EVENTS
   ------------------------------------------------------------ */
$("startBtn").addEventListener("click", () => Quiz.start());
$("nextBtn").addEventListener("click", () => Quiz.afterWrongPopup());
$("levelOk").addEventListener("click", () => Quiz.afterLevelPopup());
$("adBtn").addEventListener("click", onAdButton);
$("refreshBtn").addEventListener("click", () => Data.refresh(true));
$("soundBtn").addEventListener("click", () => {
  save.soundOn = !save.soundOn;
  persist();
  if (!save.soundOn) Voice.stop();
  syncSoundBtn();
});

let hiddenHold = false;
document.addEventListener("visibilitychange", () => {
  if (document.hidden) {
    Voice.stop();
    if (!hiddenHold) { hiddenHold = true; Timer.hold(); }
  } else {
    if (hiddenHold) { hiddenHold = false; Timer.release(); }
    Data.refresh(false);          // wapas aate hi sheet dobara check
    Boxes.render();
  }
});

/* ------------------------------------------------------------
   13. START
   ------------------------------------------------------------ */
(function init() {
  loadSave();

  // Pehle: cache -> warna fallback.js, taake app foran khule
  const cached = Data.readCache();
  const startData = cached || window.FALLBACK_DATA || { config: {}, questions: [], boxes: [] };
  Data.apply(startData);
  applyConfig();
  Boxes.render();
  setSync(false, cached ? "cache" : "offline");

  Ads.init();
  Data.refresh(false);                                   // phir foran Sheet se naya data
  const every = Math.max(15, Math.floor(num(APP.REFRESH_SECONDS, 60)));
  setInterval(() => { if (!document.hidden) Data.refresh(false); }, every * 1000);
  setInterval(() => Boxes.render(), 60 * 1000);          // reward box ka countdown
})();
