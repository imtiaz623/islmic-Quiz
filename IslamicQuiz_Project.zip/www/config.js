/* ==========================================================
   ISLAMIC QUIZ - Basic settings (sirf ye file kabhi kabhi badalni hoti hai)
   Baaki sab kuch (sawal, rang, text, coins, timer, boxes) Google Sheet se badalta hai.
   ========================================================== */
window.APP_CONFIG = {

  // Google Apps Script "Web app URL" yahan paste karein (google_sheet/README_URDU.md dekhein).
  // Khali chhodein to app sirf andar ke 42 sawal use karega.
  SHEET_API_URL: "https://script.google.com/macros/s/AKfycbwttjv51dJ_Wh-YqrpdHb_jkKpUb6MwraS5IEASncxVoDI8G5E-1nfBn70JYk_3hf0/exec",

  // AdMob IDs
  ADMOB: {
    APP_ID:              "ca-app-pub-5125432512822562~4338871619",
    BANNER_AD_UNIT_ID:   "ca-app-pub-5125432512822562/5307292170",
    REWARDED_AD_UNIT_ID: "ca-app-pub-5125432512822562/2361564639",

    // Google ke official test ad units (Sheet ke Config tab mein test_ads = TRUE karne par use hote hain)
    TEST_BANNER_AD_UNIT_ID:   "ca-app-pub-3940256099942544/6300978111",
    TEST_REWARDED_AD_UNIT_ID: "ca-app-pub-3940256099942544/5224354917"
  },

  // Sheet ko kitne second baad dobara check karna hai (app khula ho to)
  REFRESH_SECONDS: 60
};
